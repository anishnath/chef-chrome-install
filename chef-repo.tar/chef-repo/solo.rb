file_cache_path "/home/ubuntu/chef-solo"
cookbook_path "/home/ubuntu/chef-repo/cookbooks"
