# 0.1.1

Install dependencies on Ubuntu

# 0.1.0

Initial release of mozilla-firefox
