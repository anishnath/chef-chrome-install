cookbook_path [ '~/chef-repo/cookbooks' ]
